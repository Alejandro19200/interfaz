﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace Formularios
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Inicio()
        {
            string connect = "datasource=localhost;port=3306;username=root;password=;database=sistema";
            string query = "select * from principal where user = '" + textBox1.Text + "' AND password =SHA1 ('" + textBox2.Text + "')";
            MySqlConnection databaseConnection = new MySqlConnection(connect);
            MySqlCommand commandDatabase = new MySqlCommand(query, databaseConnection);
            commandDatabase.CommandTimeout = 60;
            MySqlDataReader reader;

            try
            {
                databaseConnection.Open();
                reader = commandDatabase.ExecuteReader();

                if (reader.Read())
                {
                    Welcome registra = new Welcome();
                    registra.Visible = true;
                    this.Dispose(false);
                    databaseConnection.Close();
                }
                else
                {
                    MessageBox.Show("Failed to Login");
                }
            
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Inicio();
            textBox1.Text = "";
            textBox2.Text = "";


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 registra = new Form2();
            registra.Visible= true;
            this.Dispose(false);




        }

        private void button3_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
