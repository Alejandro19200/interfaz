﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Formularios
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }
        private void GuardarUsuario()
        {
            if (textBox2.Text == textBox3.Text)
            {
                string connection = "datasource=localhost;port=3306;username=root;password=;database=sistema";
                string query = "INSERT INTO principal(`id`, `user`, `password`) VALUES (NULL, '" + textBox1.Text + "',SHA1('" + textBox2.Text + "'))";
                MySqlConnection conectionDatabase = new MySqlConnection(connection);
                MySqlCommand databaseCommand = new MySqlCommand(query, conectionDatabase);
                databaseCommand.CommandTimeout = 60;

                try
                {
                    conectionDatabase.Open();
                    MySqlDataReader reader1 = databaseCommand.ExecuteReader();
                    MessageBox.Show("¡Successful registration!");
                    Welcome registra = new Welcome();
                    registra.Visible = true;
                    this.Dispose(false);
                    conectionDatabase.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("¡Verify that the passwords match!");
            }


        }
        private void button1_Click(object sender, EventArgs e)
        {
            GuardarUsuario();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 registra = new Form1();
            registra.Visible = true;
            this.Dispose(false);
            


        }

    }
}

